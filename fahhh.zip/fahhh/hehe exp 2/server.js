const http=require('http')
const PORT=3000
const server=http.createServer((req,res)=>{
    res.writeHead(200,{
        "Content-type":"text/html"
    })

    res.write(`
        
        <h1>This is my first node server<h1>
        <i>this is istalic text</i>
        <br>gg</br>
        <b>This is bold text</b>
        
        
        `)

    res.end()
})

server.listen(PORT,()=>{
    console.log(`The server is running at http://localhost: ${PORT}`)
})