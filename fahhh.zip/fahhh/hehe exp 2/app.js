const express = require('express');
const path = require('path');

const app = express();

// Serve static files from the public folder
app.use(express.static(path.join(__dirname, 'public')));

// Home page route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// About page route
app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

// Hello route
app.get('/hello', (req, res) => {
    res.send('Hello from Express Server');
});

// Start the server
app.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});
