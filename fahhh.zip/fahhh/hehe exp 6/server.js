
const express = require('express');
const mysql = require('mysql2');
const session = require('express-session');
const path = require('path');

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
    secret: 'mysecretkey',
    resave: false,
    saveUninitialized: false
}));

// EJS configuration
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// MySQL connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '[PASSWORD]',
    database: 'wad_crud'
});

db.connect((err) => {
    if (err) {
        console.log(err);
    } else {
        console.log('MySQL Connected');
    }
});

// Authentication middleware
function auth(req, res, next) {
    if (req.session.userId) {
        next();
    } else {
        return res.status(401).json({
            message: 'Please login first'
        });
    }
}

// Page authentication middleware
function checkLogin(req, res, next) {
    if (req.session.userId) {
        next();
    } else {
        res.redirect('/');
    }
}

// Login page
app.get('/', (req, res) => {
    res.render('login');
});

// Login authentication
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    const sql = 'SELECT * FROM users WHERE username = ? AND password = ?';

    db.query(sql, [username, password], (err, result) => {
        if (err) {
            return res.send('Database error');
        }

        if (result.length > 0) {
            req.session.userId = result[0].user_id;
            res.redirect('/dashboard');
        } else {
            res.send('Invalid username or password');
        }
    });
});

// Dashboard
app.get('/dashboard', checkLogin, (req, res) => {
    res.render('dashboard');
});

// To-Do page
app.get('/todos', checkLogin, (req, res) => {
    res.render('todos');
});

// Logout
app.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/');
    });
});

// CREATE API - POST
app.post('/api/todos', auth, (req, res) => {
    const { task_description } = req.body;
    const userId = req.session.userId;

    if (!task_description || !task_description.trim()) {
        return res.status(400).json({
            message: 'Task description is required'
        });
    }

    const sql = 'INSERT INTO todos (user_id, task_description) VALUES (?, ?)';

    db.query(sql, [userId, task_description], (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Database error' });
        }

        res.status(201).json({
            message: 'Task created successfully',
            task_id: result.insertId
        });
    });
});

// READ API - GET
app.get('/api/todos', auth, (req, res) => {
    const userId = req.session.userId;

    const sql = 'SELECT * FROM todos WHERE user_id = ?';

    db.query(sql, [userId], (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Database error' });
        }

        res.status(200).json(result);
    });
});

// UPDATE API - PUT
app.put('/api/todos/:id', auth, (req, res) => {
    const taskId = req.params.id;
    const userId = req.session.userId;
    const { task_description, status } = req.body;

    const sql = `UPDATE todos
                 SET task_description = ?, status = ?
                 WHERE task_id = ? AND user_id = ?`;

    db.query(sql, [task_description, status, taskId, userId],
        (err, result) => {
            if (err) {
                return res.status(500).json({
                    message: 'Database error'
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    message: 'Task not found'
                });
            }

            res.status(200).json({
                message: 'Task updated successfully'
            });
        }
    );
});

// DELETE API - DELETE
app.delete('/api/todos/:id', auth, (req, res) => {
    const taskId = req.params.id;
    const userId = req.session.userId;

    const sql = 'DELETE FROM todos WHERE task_id = ? AND user_id = ?';

    db.query(sql, [taskId, userId], (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Database error' });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: 'Task not found'
            });
        }

        res.status(200).json({
            message: 'Task deleted successfully'
        });
    });
});

// Start server
app.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});
