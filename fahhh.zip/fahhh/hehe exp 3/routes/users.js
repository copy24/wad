const express = require('express');
const router = express.Router();

const db = require('../database');


// CREATE - Register User

router.post('/register', async (req, res) => {

    const { name, email, mobile, password } = req.body;

    const sql = "INSERT INTO users (name, email, mobile, password) VALUES (?, ?, ?, ?)";

    await db.execute(sql, [name, email, mobile, password]);

    res.send("User Registered Successfully! <a href='/'>Go Back</a>");

});


// READ - Display All Users

router.get('/users', async (req, res) => {

    const [users] = await db.execute("SELECT * FROM users");

    let output = "<h2>Registered Users</h2>";

    users.forEach(user => {

        output += `
            <p>
                ID: ${user.id} |
                Name: ${user.name} |
                Email: ${user.email} |
                Mobile: ${user.mobile}

                <a href="/update/${user.id}">Edit</a>

                <form action="/delete/${user.id}" method="POST" style="display:inline">
                    <button type="submit">Delete</button>
                </form>
            </p>
        `;

    });

    output += "<br><a href='/'>Register New User</a>";

    res.send(output);

});


// UPDATE - Display Edit Form

router.get('/update/:id', async (req, res) => {

    const id = req.params.id;

    const [users] = await db.execute(
        "SELECT * FROM users WHERE id = ?", [id]
    );

    if (users.length === 0) {
        return res.send("User Not Found");
    }

    const user = users[0];

    res.send(`
        <h2>Update User</h2>

        <form action="/update/${user.id}" method="POST">

            Name:
            <input type="text" name="name" value="${user.name}" required><br><br>

            Email:
            <input type="email" name="email" value="${user.email}" required><br><br>

            Mobile:
            <input type="text" name="mobile" value="${user.mobile}" required><br><br>

            Password:
            <input type="password" name="password" value="${user.password}" required><br><br>

            <button type="submit">Update</button>

        </form>
    `);

});


// UPDATE - Save Updated Details

router.post('/update/:id', async (req, res) => {

    const id = req.params.id;

    const { name, email, mobile, password } = req.body;

    const sql = `
        UPDATE users
        SET name = ?, email = ?, mobile = ?, password = ?
        WHERE id = ?
    `;

    const [result] = await db.execute(
        sql, [name, email, mobile, password, id]
    );

    if (result.affectedRows === 0) {
        return res.send("User Not Found");
    }

    res.send("User Updated Successfully! <a href='/users'>View Users</a>");

});


// DELETE - Remove User

router.post('/delete/:id', async (req, res) => {

    const id = req.params.id;

    await db.execute(
        "DELETE FROM users WHERE id = ?", [id]
    );

    res.redirect('/users');

});


module.exports = router;