const express = require('express');
const bodyParser = require('body-parser');

const path = require('path');

const app = express();


// Middleware

app.use(bodyParser.urlencoded({ extended: true }));


// Static Folder

app.use(express.static(path.join(__dirname, 'public')));

// Root Route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


// Import Routes

const userRoutes = require('./routes/users');

app.use('/', userRoutes);


// Start Server

app.listen(3000, () => {

    console.log("Server running at http://localhost:3000");

});