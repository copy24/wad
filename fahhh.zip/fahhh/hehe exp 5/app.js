
const express = require("express");
const mysql = require("mysql2");
const helmet = require("helmet");
const session = require("express-session");
const { body, validationResult } = require("express-validator");
const { csrfSync } = require("csrf-sync");
const path = require("path");

const app = express();

// EJS configuration
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

// Middleware
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
app.use(helmet());

// Session configuration
app.use(session({
    secret: "change-this-secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        sameSite: "lax",
        secure: false
    }
}));

// MySQL connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password:"[PASSWORD]",
    database: "secure_node_app"
});

db.connect((err) => {
    if (err) {
        console.log(err);
    } else {
        console.log("MySQL Connected Successfully");
    }
});

// CSRF protection
const {
    generateToken,
    csrfSynchronisedProtection
} = csrfSync({
    getTokenFromRequest: (req) => req.body._csrf
});

// Login page
app.get("/", (req, res) => {
    const csrfToken = generateToken(req);
    res.render("login", { csrfToken });
});

// Login with validation and SQL Injection protection
app.post(
    "/login",
    csrfSynchronisedProtection,

    body("username")
        .trim()
        .isLength({ min: 3, max: 50 }),

    body("password")
        .isLength({ min: 8 }),

    (req, res) => {

        const errors = validationResult(req);

        if (!errors.isEmpty()) {
            return res.status(400).send("Invalid Input");
        }

        const username = req.body.username;
        const password = req.body.password;

        // Parameterized SQL query
        const query =
            "SELECT * FROM users WHERE username = ? AND password = ?";

        db.execute(query, [username, password], (err, results) => {

            if (err) {
                return res.status(500).send("Database Error");
            }

            if (results.length > 0) {

                req.session.username = results[0].username;

                res.redirect("/dashboard");

            } else {
                res.send("Invalid Username or Password");
            }
        });
    }
);

// Dashboard page
app.get("/dashboard", (req, res) => {

    if (!req.session.username) {
        return res.redirect("/");
    }

    const csrfToken = generateToken(req);

    res.render("dashboard", {
        username: req.session.username,
        csrfToken
    });
});

// Logout with CSRF protection
app.post("/logout", csrfSynchronisedProtection, (req, res) => {

    req.session.destroy(() => {
        res.redirect("/");
    });

});

// Handle invalid CSRF tokens
app.use((err, req, res, next) => {

    if (err.code === "EBADCSRFTOKEN") {
        return res.status(403).send("Invalid CSRF Token");
    }

    next(err);
});

// Start server
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
