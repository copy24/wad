
// Import the HTTP module
const http = require('http');

// Create an HTTP server
const server = http.createServer((req, res) => {

    // Set the response status and content type
    res.writeHead(200, {
        'Content-Type': 'text/html'
    });

    // Send HTML content to the browser
    res.write("<h1>Welcome to JavaScript Web Server</h1>");
    res.write("<h2>Node.js Practical</h2>");
    res.write("<p>Server is running successfully.</p>");

    // End the response
    res.end();
});

// Start the server on port 3000
server.listen(3000, () => {
    console.log("Server is running on http://localhost:3000");
});
