
const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const session = require('express-session');
const path = require('path');

const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// EJS setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// MySQL connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '[PASSWORD]',
    database: 'registration_db'
});

db.connect((err) => {
    if (err) throw err;
    console.log('MySQL Connected');
});

// Session configuration
app.use(session({
    secret: 'mysecretkey',
    resave: false,
    saveUninitialized: false
}));

// Home page
app.get('/', (req, res) => {
    res.render('index');
});

// User Registration
app.post('/register', async (req, res) => {
    const { name, email, password } = req.body;

    const hashedPassword = await bcrypt.hash(password, 10);

    const sql = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';

    db.query(sql, [name, email, hashedPassword], (err, result) => {
        if (err) {
            return res.send('Registration failed. Email may already exist.');
        }

        res.send('Registration successful! <a href="/">Login</a>');
    });
});

// User Login
app.post('/login', (req, res) => {
    const { email, password } = req.body;

    const sql = 'SELECT * FROM users WHERE email = ?';

    db.query(sql, [email], async (err, result) => {
        if (err) return res.send('Database error');

        if (result.length === 0) {
            return res.send('User not found');
        }

        const user = result[0];

        const match = await bcrypt.compare(password, user.password);

        if (match) {
            req.session.user = user;
            res.redirect('/dashboard');
        } else {
            res.send('Invalid password');
        }
    });
});

// Middleware to check login
function checkLogin(req, res, next) {
    if (req.session.user) {
        next();
    } else {
        res.send('Please login first');
    }
}

// Protected Dashboard
app.get('/dashboard', checkLogin, (req, res) => {
    res.render('edit', { user: req.session.user });
});

// Logout
app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) return res.send('Logout failed');

        res.redirect('/');
    });
});

// Start server
app.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});
